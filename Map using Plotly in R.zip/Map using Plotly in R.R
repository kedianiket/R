rm(list=ls()); cat("\014") # Clear Workspace and Console

library(dplyr)
library(plotly)
library(htmlwidgets)



df<- read.csv("df.csv")

df$Color = factor(df$Color)



p <- plot_geo(df, locationmode = 'USA-states') %>%
  add_trace(    z = ~as.numeric(df$Color), locations = df$ST,
                color = ~as.numeric(df$Color),  colors = c("Blue","Red"),
                showscale = FALSE
  ) %>%  layout(geo = list(scope = "usa"))



p

saveWidget(p, 'USA Map.html') 


write.csv(df,"df.csv")



