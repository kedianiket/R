library(dplyr)
library(plotly)
library(htmlwidgets)



df <- read.csv("graph.csv")



p <- plot_geo(df, locationmode = 'world') %>%
  add_trace(    z = ~df$new_cases_per_million, locations = df$code, frame=~df$start_of_week,
                color = ~df$new_cases_per_million)

p

htmlwidgets::saveWidget(p, file = "map.html")
