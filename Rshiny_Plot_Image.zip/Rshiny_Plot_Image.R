library(shiny)
library(exifr)
library(leaflet)
library(DT)
library(shinyWidgets)

# Set ExifTool path
options(exifr.exiftool = "E:/Blog/R/Plot Images/Exif/exiftool.exe") 
options(exifr.perlpath='E:/Blog/R/Plot Images/Exif/exiftool_files')
options(shiny.maxRequestSize = 50 * 1024^2)  # 50 MB

ui <- fluidPage(
  titlePanel("EXIF Image Mapper (Multiple Files)"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput("images", "Upload JPG images", accept = c(".jpg", ".jpeg"), multiple = TRUE),
      helpText("Only images with GPS data will be plotted on the map."),
      switchInput("darkTheme", "Dark Theme", value = FALSE),
      br(),
      downloadButton("download_exif", "Download EXIF Table")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("Map", leafletOutput("map", height = 500)),
        tabPanel("EXIF Table", DTOutput("exif_table"))
      )
    )
  )
)

server <- function(input, output, session) {
  
  exif_data <- reactive({
    req(input$images)
    
    # Create www/uploads folder if it doesn't exist
    upload_dir <- "www/uploads"
    if (!dir.exists(upload_dir)) {
      dir.create(upload_dir, recursive = TRUE)
    }
    
    # Copy uploaded images to www/uploads
    file_paths <- file.path(upload_dir, input$images$name)
    file.copy(from = input$images$datapath, to = file_paths, overwrite = TRUE)
    
    # Read EXIF
    all_exif <- read_exif(input$images$datapath)
    selected <- all_exif[, c("FileName", "FileSize", "Model", "DateTimeOriginal", "GPSLatitude", "GPSLongitude")]
    names(selected) <- c("File Name", "Size", "Camera Model", "Date/Time", "Latitude", "Longitude")
    
    # Add browser-friendly image path for popup
    #selected$ImagePath <- paste0("uploads/", selected$`File Name`)
    selected
  })
  
  output$exif_table <- renderDT({
    datatable(exif_data(), options = list(pageLength = 10))
  })
  
  output$download_exif <- downloadHandler(
    filename = function() {
      paste0("EXIF_Data_", Sys.Date(), ".csv")
    },
    content = function(file) {
      write.csv(exif_data(), file, row.names = FALSE)
    }
  )
  
  output$map <- renderLeaflet({
    req(input$images)
    data <- exif_data()
    data$Latitude <- as.numeric(data$Latitude)
    data$Longitude <- as.numeric(data$Longitude)
    gps_data <- subset(data, !is.na(Latitude) & !is.na(Longitude))
    
    basemap <- if (input$darkTheme) "CartoDB.DarkMatter" else "CartoDB.Positron"
    
    leaflet() %>%
      addProviderTiles(basemap) %>%
      {
        if (nrow(gps_data) > 0) {
          addMarkers(., data = gps_data,
                     lng = ~Longitude, lat = ~Latitude,
                     popup = ~paste0(
                       "<div style='max-width: 220px;'>",
                       "<b>", `File Name`, "</b><br>",
                       "Model: ", `Camera Model`, "<br>",
                       "Size: ", Size, "<br>",
                       "Date: ", `Date/Time`, "<br><br>",
                      # "<img src='", ImagePath, "' width='180' style='border-radius: 6px;'/>",
                       "</div>"),
                     clusterOptions = markerClusterOptions()) %>%
            addMiniMap(toggleDisplay = TRUE) %>%
            addScaleBar(position = "bottomleft")
        } else {
          addPopups(., 0, 0, "No GPS data found in uploaded images",
                    options = popupOptions(closeButton = FALSE))
        }
      }
  })
}

shinyApp(ui, server)
